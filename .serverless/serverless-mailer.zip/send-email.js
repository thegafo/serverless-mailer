
var request = require('request');


// Configure the request
var options = {
    url: 'https://7ttzkegsn9.execute-api.us-east-1.amazonaws.com/dev/email',
    method: 'POST',
    json: {
      gmail: "info@aquassurance.com",
      password: "",

    }
}

// Start the request
request(options, function (error, response, body) {
  console.log(error,response.statusCode, body);
})
